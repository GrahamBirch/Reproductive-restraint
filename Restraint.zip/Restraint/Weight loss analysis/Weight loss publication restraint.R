library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)

#Key
  #bstate= Behavioural state
  #epsG = Group ID
  #epsM = Male ID
  #epsO = oestrus event ID
  


#Main output objects

#Model object
ms.weightdif10.pcw.state12
#Significance tables fixed effects
fit.table.ms.weightdif10.pcw.state12
#Significance tables random effect variance
variancerand


weightdifsdf10.pcw<-read_csv("weightlossdate.csv")
weightdifsdf10.pcw12<-weightdifsdf10.pcw%>%filter(staten!=2)%>%mutate(staten=ifelse(staten==3, 1,0))%>%
  mutate(malen=as.numeric(as.factor(indiv)))%>%
  mutate(coden=as.numeric(as.factor(oestrus.code)))%>%
  mutate(groupn=as.numeric(as.factor(groupn)))

sd1<-sd(weightdifsdf10.pcw12$agerank,na.rm=TRUE)
mean1<-mean(weightdifsdf10.pcw12$agerank,na.rm=TRUE)
recoveragerank <- function(x){(sd1*(x))+mean1}
standagerank <-function(x){(x-mean1)/sd1}

sd2<-sd(weightdifsdf10.pcw12$age,na.rm=TRUE)
mean2<-mean(weightdifsdf10.pcw12$age,na.rm=TRUE)
recoverage <- function(x){(sd2*(x))+mean2}
standage <-function(x){(x-mean2)/sd2}

sd3<-sd(weightdifsdf10.pcw12$timea,na.rm=TRUE)
mean3<-mean(weightdifsdf10.pcw12$timea,na.rm=TRUE)
recovertimea <- function(x){(sd3*(x))+mean3}
standtimea <-function(x){(x-mean3)/sd3}

sd4<-sd(weightdifsdf10.pcw12$length,na.rm=TRUE)
mean4<-mean(weightdifsdf10.pcw12$length,na.rm=TRUE)
recoverlength <- function(x){(sd4*(x))+mean4}
standlength <-function(x){(x-mean4)/sd4}


sd5<-sd(weightdifsdf10.pcw12$mfratio,na.rm=TRUE)
mean5<-mean(weightdifsdf10.pcw12$mfratio,na.rm=TRUE)
recovermfratio <- function(x){(sd5*(x))+mean5}
standmfratio <-function(x){(x-mean5)/sd5}

sd7<-sd(weightdifsdf10.pcw12$weightb,na.rm=TRUE)
mean7<-mean(weightdifsdf10.pcw12$weightb,na.rm=TRUE)
recoverweightb <- function(x){(sd7*(x))+mean7}
standweightb <-function(x){(x-mean7)/sd7}


parameters.wdif <- c(#"M",
  #  "psiA","psiB","psiC", 
  "alpha","bState","epsM",
  "epsO"
  , "epsG"#, "epsO", "WAIC"
)

inits.wdif <- function(){list(alpha=runif(1)
)}


jags.data.weightdif10.pcw12<- list( y = (
  weightdifsdf10.pcw12$weightdif),n = length(weightdifsdf10.pcw12$weightdif),
  ar=standagerank(weightdifsdf10.pcw12$agerank),
  age=standage(weightdifsdf10.pcw12$age),
  timea=standtimea(weightdifsdf10.pcw12$timea),
  leng=standlength(weightdifsdf10.pcw12$length),
  mf=standmfratio(weightdifsdf10.pcw12$mfratio),
  cw=standweightb(weightdifsdf10.pcw12$weightb),
  staten= (weightdifsdf10.pcw12$staten),
  code = weightdifsdf10.pcw12$coden,
  group = weightdifsdf10.pcw12$groupn,
  male = weightdifsdf10.pcw12$malen,
  malel= length(levels(as.factor(round(weightdifsdf10.pcw12$malen)))),
  codel= length(levels(as.factor(round(weightdifsdf10.pcw12$coden)))),
  statel= length(levels(as.factor(round(weightdifsdf10.pcw12$staten)))),
  groupl= length(levels(as.factor(round(weightdifsdf10.pcw12$groupn)))))




sink("weightdif.mod.2state")
cat(" 
  model{ 
    # likelihood
    for (i in 1:n){
            y[i] ~ dnorm(mu[i], tau)
            mu[i] <- alpha 

                        +bState*staten[i]
    }
    # priors
alpha ~ dnorm(0, .001)
bState~ dnorm(0, .001)

	sigma ~ dunif(0, 100) # standard deviation
	tau <- 1 / (sigma * sigma) # sigma^2 doesn't work in JAGS


tau.oc <- 1 / (sd.oc*sd.oc)
sd.oc ~ dunif(0, 1)
tau.g <- 1 / (sd.g*sd.g)
sd.g ~ dunif(0, 1)
tau.m <- 1 / (sd.m*sd.m)
sd.m ~ dunif(0, 1)

for(i in 1:codel){
epsO[i]~ dnorm(0,tau.oc)}
for(i in 1:groupl){
epsG[i]~ dnorm(0,tau.g)}
for(i in 1:malel){
epsM[i]~ dnorm(0,tau.m)}}")
sink()


ni <-20000
nt <- 200
nb <-2000
nc <- 3



ms.weightdif10.pcw.state12<-jagsUI::jags(jags.data.weightdif10.pcw12, inits.wdif, parameters.wdif, "weightdif.mod.2state", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE,DIC=T)#Beh?




#Constructing output table

ms.weightdif10.pcw.state12sum<-MCMCsummary(ms.weightdif10.pcw.state12, round = 2)%>%rename(low = "2.5%", high = "97.5%")

ms.weightdif10.pcw.state12sum.olap<-ms.weightdif10.pcw.state12sum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                              low < 0 & high< 0~"-",
                                                                                              TRUE ~"NotSignif"))



write.csv(ms.weightdif10.pcw.state12sum.olap, "Oms.weightdif10.pcw.state12sum.olap.csv")#to make ghost name column a real column
fit.table.ms.weightdif10.pcw.state12<-read.csv("Oms.weightdif10.pcw.state12sum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(ms.weightdif10.pcw.state12$f)),as.data.frame(matrix(unlist(ms.weightdif10.pcw.state12$f ))))%>%rename("X"="names(unlist(ms.weightdif10.pcw.state12$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it



variancerand<-ggs(ms.weightdif10.pcw.state12$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()



#Significance plots and model diagnostics




ggms.weightdif10.pcw.state12<-ggs(ms.weightdif10.pcw.state12$samples)%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('eps', Parameter))%>%mutate(Parameter=case_when(
  Parameter=="bState" ~ "State (Guard)"
))%>%arrange(desc(Parameter))%>%na.omit()

catwloss12<-ggs_caterpillar(ggms.weightdif10.pcw.state12%>%drop_na(Parameter), line=0, sort=FALSE)+ theme_classic()+ xlim(-3.5,1)+
  labs(x="Posterior probability (HPD) for weight change (% of bodyweight)", y="")+scale_y_discrete(limits=rev)


ggs_density(ggms.weightdif10.pcw.state12, hpd=TRUE)+xlim(-3.5,1)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggms.weightdif10.pcw.state12)#compares whole chain with the last value
ggs_autocorrelation(ggms.weightdif10.pcw.state12)
ggs_traceplot(ggms.weightdif10.pcw.state12)#traceplot of convergence





