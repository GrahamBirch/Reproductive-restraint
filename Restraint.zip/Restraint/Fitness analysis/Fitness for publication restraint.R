library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)
#Key
#betaa, betaaq =age, age^2
#betaar=age rank
#betagcw = group centered weight
#epsg = group
#eps0 = oestrus code.
#epsm = male .id


#Main output objects

#Model objects
#Age rank and weight
msfit0.sigPG.binom.justgcwar
#Age and weight
msfit0.sigPG.binom.justgcwage

#Significance tables fixed effects
#Age and weight
fit.table.binom.gcwage
#Age rank and weight
fit.table.binom.gcwar

#Significance tables random effect variance
#Age and weight
variancerandgcwage
#Age rank and weight
variancerandgcwar









oestrusmaleargcwcompfitness<-read_csv("ageweightfitnessdata.csv")


meangcw=mean(oestrusmaleargcwcompfitness$grpcenteredweight)
sdgcw = sd(oestrusmaleargcwcompfitness$grpcenteredweight)
recoverOgcw <- function(x){(sdgcw*(x))+meangcw}
standOgcw<-function(x){(x-meangcw)/sdgcw}
meanage=mean(oestrusmaleargcwcompfitness$avg.M.age.event)
sdage = sd(oestrusmaleargcwcompfitness$avg.M.age.event)
recoverOage <- function(x){(sdage*(x))+meanage}
standOage<-function(x){(x-meanage)/sdage}



jags.data.fitO0PG.gcwar.binom <- list( y = oestrusmaleargcwcompfitness$oesoffn.male,n = length(oestrusmaleargcwcompfitness$oesoffn.male),
                                       gcw=standOgcw(oestrusmaleargcwcompfitness$grpcenteredweight),
                                       ar=oestrusmaleargcwcompfitness$male.age.rank,
                                       offoes=oestrusmaleargcwcompfitness$oesoffn,
                                       age=standOage(oestrusmaleargcwcompfitness$avg.M.age.event),
                                       code = oestrusmaleargcwcompfitness$coden,
                                       male = oestrusmaleargcwcompfitness$malen,
                                       group = oestrusmaleargcwcompfitness$groupn,
                                       groupl= length(levels(as.factor((oestrusmaleargcwcompfitness$groupn)))),
                                       codel= length(levels(as.factor((oestrusmaleargcwcompfitness$coden)))),
                                       malel= length(levels(as.factor((oestrusmaleargcwcompfitness$malen)))))


parameters0.sig <- c(#"M",
  #  "psiA","psiB","psiC", 
  "alpha", "betagcw", "betaa", "betaaq", "betanoff", "betaar","betacomp","betastate", "betacindex","betaorder", "Fit", "FitNew"#,"betafrage", "inta.mfrage"
  ,"epsF", "epsM", "epsO","epsG","WAIC"
)
inits0 <- function(){list(alpha=runif(1),#needs to be the amount of parameters you want
                          betacomp=runif(1),
                          betaa=runif(1),
                          betaaq=runif(1),
                          betastate=runif(1),
                          betacindex=runif(1),
                          betaorder=runif(1),
                          betaar=runif(1),
                          betagcw=runif(1),
                          betanoff=runif(1),
                          inta.state.cindex=runif(1),
                          inta.state.suit=runif(1),
                          inta.state.order=runif(1),
                          inta.cindex.suit=runif(1),
                          inta.cindex.order=runif(1),
                          inta.order.suit=runif(1)
)}
ni <-20000
nt <- 100
nb <-2000
nc <- 3

sink("diad.fit.model0.justgcwar.binom.sigma")
cat("
model {
for (i in 1:n){
y[i] ~ dbin(p[i], offoes[i])#binomial mode, number of pups sired given number of pups sired in the litter
logit(p[i])  <- alpha

+betagcw*gcw[i]
+betaar*ar[i]
+epsG[group[i]]
+epsM[male[i]]
+epsO[code[i]]

}
alpha ~ dnorm(0, .001)
betagcw ~ dnorm(0, .001)
betaar ~ dnorm(0, .001)

tau.oc <- 1 / (sd.oc*sd.oc)
sd.oc ~ dunif(0, 1)
tau.m <- 1 / (sd.m*sd.m)
sd.m ~ dunif(0, 1)

tau.g <- 1 / (sd.g*sd.g)
sd.g ~ dunif(0, 1)
for(i in 1:groupl){
epsG[i]~ dnorm(0,tau.g)}

for(i in 1:codel){
epsO[i]~ dnorm(0,tau.oc)}
for(i in 1:malel){
epsM[i]~ dnorm(0,tau.m)}

}
")
sink()


sink("diad.fit.model0.justgcwage.binom.sigma")
cat("
model {
for (i in 1:n){
y[i] ~ dbin(p[i], offoes[i])
logit(p[i]) <- alpha
+betagcw*gcw[i]
+betaa*age[i]
+betaaq*age[i]^2
+epsG[group[i]]
+epsM[male[i]]
+epsO[code[i]]

}
alpha ~ dnorm(0, .001)
betagcw ~ dnorm(0, .001)
betaa ~ dnorm(0, .001)
betaaq ~ dnorm(0, .001)

beta0 ~ dnorm(0,1.0E-06)
beta1 ~ dnorm(0,1.0E-06)

tau.oc <- 1 / (sd.oc*sd.oc)
sd.oc ~ dunif(0, 1)
tau.m <- 1 / (sd.m*sd.m)
sd.m ~ dunif(0, 1)

tau.g <- 1 / (sd.g*sd.g)
sd.g ~ dunif(0, 1)
for(i in 1:groupl){
epsG[i]~ dnorm(0,tau.g)}

for(i in 1:codel){
epsO[i]~ dnorm(0,tau.oc)}
for(i in 1:malel){
epsM[i]~ dnorm(0,tau.m)}

}
")
sink()

msfit0.sigPG.binom.justgcwar<-jagsUI ::jags(jags.data.fitO0PG.gcwar.binom, inits0, parameters0.sig, "diad.fit.model0.justgcwar.binom.sigma", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE,DIC=T)#Beh?
msfit0.sigPG.binom.justgcwage<-jagsUI ::jags(jags.data.fitO0PG.gcwar.binom, inits0, parameters0.sig, "diad.fit.model0.justgcwage.binom.sigma", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE,DIC=T)#Beh?





#Getting data tables


msfit0.sigPG.binom.justgcwagesum<-MCMCsummary(msfit0.sigPG.binom.justgcwage, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(ms1sum)
msfit0.sigPG.binom.justgcwagesum.olap<-msfit0.sigPG.binom.justgcwagesum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                    low < 0 & high< 0~"-",
                                                                                                    TRUE ~"NotSignif"))


str(Omsb.id.WR.age.olap)
write.csv(msfit0.sigPG.binom.justgcwagesum.olap, "Omsfit0.sigPG.binom.justgcwagesum.olap.csv")#to make ghost name column a real column
Omsfit0.sigPG.binom.justgcwagesum.olap<-read.csv("Omsfit0.sigPG.binom.justgcwagesum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(msfit0.sigPG.binom.justgcwage$f)),as.data.frame(matrix(unlist(msfit0.sigPG.binom.justgcwage$f ))))%>%rename("X"="names(unlist(msfit0.sigPG.binom.justgcwage$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it

write.csv(Omsfit0.sigPG.binom.justgcwagesum.olap, "table.Omsfit0.sigPG.binom.justgcwagesum.olap.csv")

fit.table.binom.gcwage<-read.csv("table.Omsfit0.sigPG.binom.justgcwagesum.olap.csv")




msfit0.sigPG.binom.justgcwarsum<-MCMCsummary(msfit0.sigPG.binom.justgcwar, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(ms1sum)
msfit0.sigPG.binom.justgcwarsum.olap<-msfit0.sigPG.binom.justgcwarsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                  low < 0 & high< 0~"-",
                                                                                                  TRUE ~"NotSignif"))


str(Omsb.id.WR.age.olap)
write.csv(msfit0.sigPG.binom.justgcwarsum.olap, "Omsfit0.sigPG.binom.justgcwarsum.olap.csv")#to make ghost name column a real column
Omsfit0.sigPG.binom.justgcwarsum.olap<-read.csv("Omsfit0.sigPG.binom.justgcwarsum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(msfit0.sigPG.binom.justgcwar$f)),as.data.frame(matrix(unlist(msfit0.sigPG.binom.justgcwar$f ))))%>%rename("X"="names(unlist(msfit0.sigPG.binom.justgcwar$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it

write.csv(Omsfit0.sigPG.binom.justgcwarsum.olap, "table.Omsfit0.sigPG.binom.justgcwarsum.olap.csv")

fit.table.binom.gcwar<-read.csv("table.Omsfit0.sigPG.binom.justgcwarsum.olap.csv")


#Random effect variance
variancerandgcwar<-ggs(msfit0.sigPG.binom.justgcwar$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()
variancerandgcwage<-ggs(msfit0.sigPG.binom.justgcwage$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()



#Significance plots and model diagnostics




ggmsfit0.sigPG.binom.justgcwar<-ggs(msfit0.sigPG.binom.justgcwar$samples)
ggmsfit0.sigPG.binom.justgcwar<-ggmsfit0.sigPG.binom.justgcwar%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('eps', Parameter))%>%arrange(Parameter)#making seperate random dataframe and filtering fixed
ggs_traceplot(ggmsfit0.sigPG.binom.justgcwar%>%filter(grepl('beta', Parameter)))
ggmsfit0.sigPG.binom.justgcwar<-ggs(msfit0.sigPG.binom.justgcwar$samples)%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%filter(!grepl('eps', Parameter))%>%mutate(Parameter=case_when(
    Parameter=="betaar" ~    "AgeRank",
    Parameter=="betagcw"  ~"GroupCenteredWeight(g)"
  ))%>%arrange(desc(Parameter))%>%na.omit()

ggmsfit0.sigPG.binom.justgcwage<-ggs(msfit0.sigPG.binom.justgcwage$samples)
ggmsfit0.sigPG.binom.justgcwage<-ggmsfit0.sigPG.binom.justgcwage%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('eps', Parameter))%>%arrange(Parameter)#making seperate random dataframe and filtering fixed
ggs_traceplot(ggmsfit0.sigPG.binom.justgcwage%>%filter(grepl('beta', Parameter)))
ggmsfit0.sigPG.binom.justgcwage<-ggs(msfit0.sigPG.binom.justgcwage$samples)%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%filter(!grepl('eps', Parameter))%>%mutate(Parameter=case_when(
    Parameter=="betaa" ~    "Age",
    Parameter=="betaaq" ~    "Age^2",
    Parameter=="betagcw"  ~"GroupCenteredWeight(g)"
  ))%>%arrange(desc(Parameter))%>%na.omit()



#significance plots
ggs_caterpillar(ggmsfit0.sigPG.binom.justgcwage)+xlim(-3,3)+ geom_vline(xintercept = 0)+theme_classic()
ggs_caterpillar(ggmsfit0.sigPG.binom.justgcwar)+xlim(-1.5,1.5)+ geom_vline(xintercept = 0)+theme_classic()
ggs_density(ggmsfit0.sigPG.binom.justgcwage, hpd=TRUE)+xlim(-3,3)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")
ggs_density(ggmsfit0.sigPG.binom.justgcwar, hpd=TRUE)+xlim(-1.5,1.5)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggmsfit0.sigPG.binom.justgcwage)#compares whole chain with the last value
ggs_compare_partial(ggmsfit0.sigPG.binom.justgcwar)#compares whole chain with the last value
ggs_autocorrelation(ggmsfit0.sigPG.binom.justgcwage)
ggs_autocorrelation(ggmsfit0.sigPG.binom.justgcwar)
ggs_traceplot(ggmsfit0.sigPG.binom.justgcwage)#traceplot of convergence
ggs_traceplot(ggmsfit0.sigPG.binom.justgcwar)#traceplot of convergence
ggs_crosscorrelation(ggmsfit0.sigPG.binom.justgcwage)#check for highly correlated dependent variables (deep blue or red), age and age^2 obviously should be highly correlated
ggs_crosscorrelation(ggmsfit0.sigPG.binom.justgcwar)#check for highly correlated dependent variables (deep blue or red)
