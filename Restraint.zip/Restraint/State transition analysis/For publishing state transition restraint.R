library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)

#Key
#betafa= Female age rank
#betama = male age rank
#betar= relatedness
#betapg = Reproductive state (Guard vs pesterer)
#betanfem = number of females
#intafmapg = Interaction between female age rank, male age rank and reproductive state.
#intafapg, intamapg, intafma = two way interactions
#epsF = Female ID
#epsM = Male ID
#epsO = oestrus event ID


#Main output objects


#Model objects
#Age rank and group centered weight
OpmsbGid.justfixedgcw.ager
OpmsbGid.justfixedgcw.ager.inv

#Age and group centered weight
OpmsbGid.justfixedgcw.age
OpmsbGid.justfixedgcw.age.inv


#Significance tables fixed effects
#Age rank and group centered weight
table.OpmsbGid.justfixedgcw.ager
#Age and group centered weight
table.OpmsbGid.justfixedgcw.age
#Significance tables random effect variance
#Age rank and group centered weight
variancerand
#Age and group centered weight
variancerand2


initsall<- function(){list(#alpha0=runif(3, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha1=runif(2, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha2=runif(2, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha3=runif(2, 1e-9, 1e-7),
  beta1=runif(2, 1e-9, 1e-7),
  beta2=runif(2, 1e-9, 1e-7),
  beta3=runif(2, 1e-9, 1e-7),
  betaq1=runif(2, 1e-9, 1e-7),
  betaq2=runif(2, 1e-9, 1e-7),
  betaq3=runif(2, 1e-9, 1e-7),
  betacw1=runif(2, 1e-9, 1e-7),
  betacw2=runif(2, 1e-9, 1e-7),
  betacw3=runif(2, 1e-9, 1e-7)

)}

Oparameters.all <- c(
  "alpha1", "alpha2", "alpha3", 
  "epsM1","epsM2","epsM3", 
  "beta1", "beta2", "beta3",
  "epsO1","epsO2","epsO3", 
  "betamf1", "betamf2", "betamf3",
  "betacw1", "betacw2", "betacw3",
  "betaq1","betaq2","betaq3",
  "epsG1", "epsG2", "epsG3")

code<-read_csv("matrixoestrus.codenum.csv")
code <-t(as.matrix(code))


group <-read_csv("matrixgroupnum.csv")
group <- t(as.matrix(group))



pCH1 <- read_csv("matrixstatepest.csv")
pCH <- read_csv("matrixstatepest.csv")
pCH <- t(as.matrix(pCH))

pCH[is.na(pCH)] <- 4

pCHi<-pCH
pCHi[pCHi==1]<-5#sub
pCHi[pCHi==3]<-6#guard
pCHi[pCHi==5]<-3#sub now 3
pCHi[pCHi==6]<-1#guard now 1



tableage <- read_csv("matrixage.csv")
tableage <- t(as.matrix(tableage))
meanage = mean(tableage)
sdage = sd(tableage)
recoverage <- function(x){(sdage*(x))+meanage}
standage<-function(x){(x-meanage)/sdage}
tableage <- standage(tableage)

rankage <-read_csv("matrixmale.age.rank.csv")
rankage <- t(round(as.matrix(rankage)))
rankage0<-rankage

tableage1 <- read_csv(t("matrixage.csv"))
indiv<-as.data.frame(names(tableage1))%>%rename("indiv" = "names(tableage1)")%>%mutate(num.indiv=row_number())
ind.vec <-as.matrix(indiv%>%select(num.indiv))

gcweightarchive<-as.matrix(read_csv("weightcenteredrankmatrix.csv"))
gcweightt<-as.matrix(read_csv("weightcenteredrankmatrix.csv"))
gcweight<-t(gcweightt)



Odataid.arwr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = rankage0, y = pCH,  cw = gcweight,  
                     n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])

Oinv.dataid.arwr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = rankage0, y = pCHi,  cw = gcweight,
                         n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])
Odataid.awr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = tableage, y = pCH,  cw = gcweight,  
                    n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])

Oinv.dataid.awr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = tableage, y = pCHi,  cw = gcweight,
                        n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])

#Opms





ni <-20000
nt <- 100
nb <-2500
nc <- 3





sink("OmsbG.justfixedar.idcwr")#b for base before looking at development
cat("
    model {
    
    # -------------------------------------------------
    # Parameters:
    # psiA B and C: movement probability from state to another  
    # M probbability of death - just intercept modelled

    # Priors and constraints
    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:3){
    logit(M[i,j,k])<- alpha0[k]
    
    }}} 

    tau.group1 <- 1 / (sd.group1*sd.group1)
    sd.group1 ~ dunif(0, 3)
    tau.group2 <- 1 / (sd.group2*sd.group2)
    sd.group2 ~ dunif(0, 3)
    tau.group3 <- 1 / (sd.group3*sd.group3)
    sd.group3 ~ dunif(0, 3)
 
    tau.ocode1 <- 1 / (sd.ocode1*sd.ocode1)
    sd.ocode1 ~ dunif(0, 3)
    tau.ocode2 <- 1 / (sd.ocode2*sd.ocode2)
    sd.ocode2 ~ dunif(0, 3)
    tau.ocode3 <- 1 / (sd.ocode3*sd.ocode3)
    sd.ocode3 ~ dunif(0, 3)   
    

    
    tau.male1 <- 1 / (sd.male1*sd.male1)
    sd.male1 ~ dunif(0, 3)
    tau.male2 <- 1 / (sd.male2*sd.male2)
    sd.male2 ~ dunif(0, 3)
    tau.male3 <- 1 / (sd.male3*sd.male3)
    sd.male3 ~ dunif(0, 3) 
   
    for(i in 1:3){
    alpha0[i]~dnorm(0,0.001)

    }


#run it in the same model
#take the average of the whole population
#scorting values on normal distribution defined by mean.
#mean - mean of group. 


    
    for(i in 1:2){
    alpha1[i]~dnorm(0,0.001)
    beta1[i]~dnorm(0,0.001)
    alpha2[i]~dnorm(0,0.001)
    beta2[i]~dnorm(0,0.001)
    alpha3[i]~dnorm(0,0.001)
    beta3[i]~dnorm(0,0.001)
    
    betacw1[i]~dnorm(0,0.001)
   
    betacw2[i]~dnorm(0,0.001)
    
    betacw3[i]~dnorm(0,0.001)
    
    }
    for(i in 1:n.group){
    epsG1[i]~ dnorm(0,tau.group1) 
    epsG2[i]~ dnorm(0,tau.group2) 
    epsG3[i]~ dnorm(0,tau.group3) }
    for(i in 1:n.code){
    epsO1[i]~ dnorm(0,tau.ocode1) 
    epsO2[i]~ dnorm(0,tau.ocode2) 
    epsO3[i]~ dnorm(0,tau.ocode3)}
    
    for(i in 1:n.male){
    epsM1[i]~ dnorm(0,tau.male1) 
    epsM2[i]~ dnorm(0,tau.male2) 
    epsM3[i]~ dnorm(0,tau.male3)}
    
    
    

    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:2){    
    psia[i,j,k]<-alpha1[k]+
    beta1[k]*age[i,j]+
    betacw1[k]*cw[i,j]+
    epsG1[group[i,j]]+
    epsM1[male[i]]+
    epsO1[ocode[i,j]]
    psib[i,j,k]<-alpha2[k]+
    beta2[k]*age[i,j]+
    betacw2[k]*cw[i,j]+
    epsG2[group[i,j]]+
    epsM2[male[i]]+
    epsO2[ocode[i,j]]
    psic[i,j,k]<-alpha3[k]+
    beta3[k]*age[i,j]+
    betacw3[k]*cw[i,j]+
    epsG3[group[i,j]]+
    epsM3[male[i]]+
    epsO3[ocode[i,j]]
    #The sum of the transition probabilities should be equal to 1 
    psiA[i,j,k] <- exp(psia[i,j,k])/(1+exp(psia[i,j,1])+exp(psia[i,j,2]))
    psiB[i,j,k] <- exp(psib[i,j,k])/(1+exp(psib[i,j,1])+exp(psib[i,j,2]))
    psiC[i,j,k] <- exp(psic[i,j,k])/(1+exp(psic[i,j,1])+exp(psic[i,j,2]))}
    psiA[i,j,3] <- 1-psiA[i,j,1]-psiA[i,j,2]
    psiB[i,j,3] <- 1-psiB[i,j,1]-psiB[i,j,2]
    psiC[i,j,3] <- 1-psiC[i,j,1]-psiC[i,j,2]}}

    

    # Define state-transition

    for (i in 1:nind){
    # Define probabilities of state S(t+1) given S(t)
    for (t in 1:(n.occasions-1)){
    ps[1,i,t,1] <- psiA[i,t,1]
    ps[1,i,t,2] <- psiA[i,t,2]
    ps[1,i,t,3] <- psiA[i,t,3]
    ps[1,i,t,4] <- M[i,t,1]
    ps[2,i,t,1] <- psiB[i,t,1]
    ps[2,i,t,2] <- psiB[i,t,2]
    ps[2,i,t,3] <- psiB[i,t,3]
    ps[2,i,t,4] <- M[i,t,2]
    ps[3,i,t,1] <- psiC[i,t,1]
    ps[3,i,t,2] <- psiC[i,t,2]
    ps[3,i,t,3] <- psiC[i,t,3]
    ps[3,i,t,4] <- M[i,t,3]
    ps[4,i,t,1] <- 0
    ps[4,i,t,2] <- 0
    ps[4,i,t,3] <- 0
    ps[4,i,t,4] <- 1
    } #t
    } #i
    
    # Likelihood 
    for (i in 1:nind){
    for (t in 2:n.occasions){
    # State process: draw S(t) given S(t-1)
    y[i,t] ~ dcat(ps[y[i,t-1], i, t-1,]) # This is a profile
    } #t
} #i
    }")
sink()




sink("OmsbG.justfixedage.idcwr")#b for base before looking at development
cat("
    model {
    
    # -------------------------------------------------
    # Parameters:
    # psiA B and C: movement probability from site to another   
    # M probbability of death - just intercept modelled

    # Priors and constraints
    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:3){
    logit(M[i,j,k])<- alpha0[k]

    }}} 


    tau.group1 <- 1 / (sd.group1*sd.group1)
    sd.group1 ~ dunif(0, 3)
    tau.group2 <- 1 / (sd.group2*sd.group2)
    sd.group2 ~ dunif(0, 3)
    tau.group3 <- 1 / (sd.group3*sd.group3)
    sd.group3 ~ dunif(0, 3)
 

    tau.ocode1 <- 1 / (sd.ocode1*sd.ocode1)
    sd.ocode1 ~ dunif(0, 3)
    tau.ocode2 <- 1 / (sd.ocode2*sd.ocode2)
    sd.ocode2 ~ dunif(0, 3)
    tau.ocode3 <- 1 / (sd.ocode3*sd.ocode3)
    sd.ocode3 ~ dunif(0, 3)   
    
   

    tau.male1 <- 1 / (sd.male1*sd.male1)
    sd.male1 ~ dunif(0, 3)
    tau.male2 <- 1 / (sd.male2*sd.male2)
    sd.male2 ~ dunif(0, 3)
    tau.male3 <- 1 / (sd.male3*sd.male3)
    sd.male3 ~ dunif(0, 3) 
    

    for(i in 1:3){
    alpha0[i]~dnorm(0,0.001)
    }
    
    for(i in 1:2){
    alpha1[i]~dnorm(0,0.001)
    beta1[i]~dnorm(0,0.001)
    alpha2[i]~dnorm(0,0.001)
    beta2[i]~dnorm(0,0.001)
    alpha3[i]~dnorm(0,0.001)
    beta3[i]~dnorm(0,0.001)
    betaq1[i]~dnorm(0,0.001)
    betaq2[i]~dnorm(0,0.001)
    betaq3[i]~dnorm(0,0.001)
    betacw1[i]~dnorm(0,0.001)
    betacw2[i]~dnorm(0,0.001)
    betacw3[i]~dnorm(0,0.001)
 
    
    }
    for(i in 1:n.group){
    epsG1[i]~ dnorm(0,tau.group1) 
    epsG2[i]~ dnorm(0,tau.group2) 
    epsG3[i]~ dnorm(0,tau.group3) }
    for(i in 1:n.code){
    epsO1[i]~ dnorm(0,tau.ocode1) 
    epsO2[i]~ dnorm(0,tau.ocode2) 
    epsO3[i]~ dnorm(0,tau.ocode3)}

    for(i in 1:n.male){
    epsM1[i]~ dnorm(0,tau.male1) 
    epsM2[i]~ dnorm(0,tau.male2) 
    epsM3[i]~ dnorm(0,tau.male3)}
    
    
    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:2){    
    psia[i,j,k]<-alpha1[k]+
    beta1[k]*age[i,j]+
    betaq1[k]*age[i,j]^2+
    betacw1[k]*cw[i,j]+
    epsG1[group[i,j]]+
    epsM1[male[i]]+
    epsO1[ocode[i,j]]
    #add priors #removed logit as proportions created on line 61
    psib[i,j,k]<-alpha2[k]+
    beta2[k]*age[i,j]+
    betaq2[k]*age[i,j]^2+
    betacw2[k]*cw[i,j]+
    epsG2[group[i,j]]+
    epsM2[male[i]]+
    epsO2[ocode[i,j]]
    psic[i,j,k]<-alpha3[k]+
    beta3[k]*age[i,j]+
    betaq3[k]*age[i,j]^2+
    betacw3[k]*cw[i,j]+
    epsG3[group[i,j]]+
    epsM3[male[i]]+
    epsO3[ocode[i,j]]
    #The sum of transition-to probabilities should be equal to 1

    psiA[i,j,k] <- exp(psia[i,j,k])/(1+exp(psia[i,j,1])+exp(psia[i,j,2]))
    psiB[i,j,k] <- exp(psib[i,j,k])/(1+exp(psib[i,j,1])+exp(psib[i,j,2]))
    psiC[i,j,k] <- exp(psic[i,j,k])/(1+exp(psic[i,j,1])+exp(psic[i,j,2]))}
    psiA[i,j,3] <- 1-psiA[i,j,1]-psiA[i,j,2]
    psiB[i,j,3] <- 1-psiB[i,j,1]-psiB[i,j,2]
    psiC[i,j,3] <- 1-psiC[i,j,1]-psiC[i,j,2]}}

    # Define state-transition

    for (i in 1:nind){
    # Define probabilities of state S(t+1) given S(t)
    for (t in 1:(n.occasions-1)){
    ps[1,i,t,1] <- psiA[i,t,1]
    ps[1,i,t,2] <- psiA[i,t,2]
    ps[1,i,t,3] <- psiA[i,t,3]
    ps[1,i,t,4] <- M[i,t,1]
    ps[2,i,t,1] <- psiB[i,t,1]
    ps[2,i,t,2] <- psiB[i,t,2]
    ps[2,i,t,3] <- psiB[i,t,3]
    ps[2,i,t,4] <- M[i,t,2]
    ps[3,i,t,1] <- psiC[i,t,1]
    ps[3,i,t,2] <- psiC[i,t,2]
    ps[3,i,t,3] <- psiC[i,t,3]
    ps[3,i,t,4] <- M[i,t,3]
    ps[4,i,t,1] <- 0
    ps[4,i,t,2] <- 0
    ps[4,i,t,3] <- 0
    ps[4,i,t,4] <- 1
    } #t
    } #i
    
    # Likelihood 
    for (i in 1:nind){
    for (t in 2:n.occasions){
    # State process: draw S(t) given S(t-1)
    y[i,t] ~ dcat(ps[y[i,t-1], i, t-1,]) # This is a profile
    } #t
} #i
    }")
sink()



OpmsbGid.justfixedgcw.ager<- jagsUI ::jags(Odataid.arwr.p, initsall, Oparameters.all, "OmsbG.justfixedar.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)
OpmsbGid.justfixedgcw.ager.inv<- jagsUI ::jags(Oinv.dataid.arwr.p, initsall, Oparameters.all, "OmsbG.justfixedar.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)

OpmsbGid.justfixedgcw.age<- jagsUI ::jags(Odataid.awr.p, initsall, Oparameters.all, "OmsbG.justfixedage.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)
OpmsbGid.justfixedgcw.age.inv<- jagsUI ::jags(Oinv.dataid.awr.p, initsall, Oparameters.all, "OmsbG.justfixedage.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)






OpmsbGid.justfixedgcw.agersum<-MCMCsummary(OpmsbGid.justfixedgcw.ager, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.justfixedgcw.agersum)
OpmsbGid.justfixedgcw.ager.olap<-OpmsbGid.justfixedgcw.agersum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                           low < 0 & high< 0~"-",
                                                                                           TRUE ~"NotSignif"))

write.csv(OpmsbGid.justfixedgcw.ager.olap, "OpmsbGid.justfixedgcw.ager.olap.csv")#to make ghost name column a real column
OFpmsbGid.justfixedgcw.ager.olap<-read.csv("OpmsbGid.justfixedgcw.ager.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.justfixedgcw.ager$f)),as.data.frame(matrix(unlist(OpmsbGid.justfixedgcw.ager$f ))))%>%rename("X"="names(unlist(OpmsbGid.justfixedgcw.ager$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.justfixedgcw.ager.olap, "OpmsbGid.justfixedgcw.ager.olap.csv")





OpmsbGid.justfixedgcw.ager.invsum<-MCMCsummary(OpmsbGid.justfixedgcw.ager.inv, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.justfixedgcw.ager.invsum)
OpmsbGid.justfixedgcw.ager.inv.olap<-OpmsbGid.justfixedgcw.ager.invsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                   low < 0 & high< 0~"-",
                                                                                                   TRUE ~"NotSignif"))

write.csv(OpmsbGid.justfixedgcw.ager.inv.olap, "OpmsbGid.justfixedgcw.ager.inv.olap.csv")
OFpmsbGid.justfixedgcw.ager.inv.olap<-read.csv("OpmsbGid.justfixedgcw.ager.inv.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.justfixedgcw.ager.inv$f)),as.data.frame(matrix(unlist(OpmsbGid.justfixedgcw.ager.inv$f ))))%>%rename("X"="names(unlist(OpmsbGid.justfixedgcw.ager.inv$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.justfixedgcw.ager.inv.olap, "OpmsbGid.justfixedgcw.ager.inv.olap.csv")

OFpmsbGid.justfixedgcw.ager.inv.olap<-OFpmsbGid.justfixedgcw.ager.inv.olap%>%mutate(X = gsub("3","5",X), X=gsub("1","3",X), X=gsub("5","1",X))#Correcting the inversed out put sowe can get the probabilities for transitioning to a guardning role
invkeep<-OFpmsbGid.justfixedgcw.ager.inv.olap%>%anti_join(OFpmsbGid.justfixedgcw.ager.olap, by=c("X"))#all these we want to keep!
table.OpmsbGid.justfixedgcw.ager<-rbind(OFpmsbGid.justfixedgcw.ager.olap,invkeep)%>%arrange(as.character(X))




OpmsbGid.justfixedgcw.agesum<-MCMCsummary(OpmsbGid.justfixedgcw.age, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.justfixedgcw.agesum)
OpmsbGid.justfixedgcw.age.olap<-OpmsbGid.justfixedgcw.agesum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                         low < 0 & high< 0~"-",
                                                                                         TRUE ~"NotSignif"))

write.csv(OpmsbGid.justfixedgcw.age.olap, "OpmsbGid.justfixedgcw.age.olap.csv")#to make ghost name column a real column
OFpmsbGid.justfixedgcw.age.olap<-read.csv("OpmsbGid.justfixedgcw.age.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.justfixedgcw.age$f)),as.data.frame(matrix(unlist(OpmsbGid.justfixedgcw.age$f ))))%>%rename("X"="names(unlist(OpmsbGid.justfixedgcw.age$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.justfixedgcw.age.olap, "OpmsbGid.justfixedgcw.age.olap.csv")





OpmsbGid.justfixedgcw.age.invsum<-MCMCsummary(OpmsbGid.justfixedgcw.age.inv, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.justfixedgcw.age.invsum)
OpmsbGid.justfixedgcw.age.inv.olap<-OpmsbGid.justfixedgcw.age.invsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                 low < 0 & high< 0~"-",
                                                                                                 TRUE ~"NotSignif"))

write.csv(OpmsbGid.justfixedgcw.age.inv.olap, "OpmsbGid.justfixedgcw.age.inv.olap.csv")
OFpmsbGid.justfixedgcw.age.inv.olap<-read.csv("OpmsbGid.justfixedgcw.age.inv.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.justfixedgcw.age.inv$f)),as.data.frame(matrix(unlist(OpmsbGid.justfixedgcw.age.inv$f ))))%>%rename("X"="names(unlist(OpmsbGid.justfixedgcw.age.inv$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.justfixedgcw.age.inv.olap, "OpmsbGid.justfixedgcw.age.inv.olap.csv")

OFpmsbGid.justfixedgcw.age.inv.olap<-OFpmsbGid.justfixedgcw.age.inv.olap%>%mutate(X = gsub("3","5",X), X=gsub("1","3",X), X=gsub("5","1",X))#this was kinda easy to sub in the right numbers
invkeep<-OFpmsbGid.justfixedgcw.age.inv.olap%>%anti_join(OFpmsbGid.justfixedgcw.age.olap, by=c("X"))#all these we want to keep!
table.OpmsbGid.justfixedgcw.age<-rbind(OFpmsbGid.justfixedgcw.age.olap,invkeep)%>%arrange(as.character(X))




ggsOpmsbGid.justfixedgcw.ager.eps<-rbind(ggs(OpmsbGid.justfixedgcw.ager$samples)%>%filter(grepl("eps", Parameter)),
                                         ggs(OpmsbGid.justfixedgcw.ager.inv.corrected$samples)%>%filter(grepl("eps", Parameter)) )
ggsOpmsbGid.justfixedgcw.age.eps<-rbind(ggs(OpmsbGid.justfixedgcw.age$samples)%>%filter(grepl("eps", Parameter)),
                                        ggs(OpmsbGid.justfixedgcw.age.inv$samples)%>%filter(grepl("eps", Parameter)) )


variancerand<-ggsOpmsbGid.justfixedgcw.ager.eps%>%filter(!grepl("2", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()
variancerand2<-ggsOpmsbGid.justfixedgcw.age.eps%>%filter(!grepl("2", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()










#Extracting outputs of the normal and inverse models to make the significance table. 
#From normal models are taken the parameters for transitions to subordinate roles
#From inverse models are taken the parameters for transitions to guarding roles.

ggstate<-ggs(OpmsbGid.justfixedgcw.age$samples)
ggstateinv<-ggs(OpmsbGid.justfixedgcw.age.inv$samples)

ggstaterand<-ggstate%>%filter(str_detect(Parameter, 'eps'))#making seperate random dataframe and filtering fixed
ggstate<-filter(ggstate, !grepl('eps', Parameter))
ggstateb<-ggstate
ggstateinv<-filter(ggstateinv, !grepl('eps', Parameter))
ggstateinvb<-ggstateinv
ggstate$Parameter<-str_replace_all(ggstate$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Sub.to.sub")%>%
  str_replace("12", "Sub.to.pest")%>%
  str_replace("22", "Pest.to.pest")%>%
  str_replace("21", "Pest.to.sub")%>%
  str_replace("31", "Guard.to.sub")%>%
  str_replace("32", "Guard.to.pest")

view(ggstate)
ggstateinv$Parameter<-str_replace_all(ggstateinv$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Guard.to.guard")%>%
  str_replace("21", "Pest.to.guard")%>%
  str_replace("31", "Sub.to.guard")

ggstateinv2<-ggstateinv%>%
  filter(str_detect(Parameter, 'guard'))
#joining fixed so sub/pest/guard combined!



ggstatejustgcwaint<-rbind(ggstate,ggstateinv2)%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('deviance', Parameter))
unique(ggstate$Parameter)

unique(ggstateinv2$Parameter)



ggstate<-ggs(OpmsbGid.justfixedgcw.ager$samples)
ggstateinv<-ggs(OpmsbGid.justfixedgcw.ager.inv$samples)


ggstaterand<-ggstate%>%filter(str_detect(Parameter, 'eps'))#making seperate random dataframe and filtering fixed
ggstate<-filter(ggstate, !grepl('eps', Parameter))
ggstateb<-ggstate
ggstateinv<-filter(ggstateinv, !grepl('eps', Parameter))
ggstateinvb<-ggstateinv
ggstate$Parameter<-str_replace_all(ggstate$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Sub.to.sub")%>%
  str_replace("12", "Sub.to.pest")%>%
  str_replace("22", "Pest.to.pest")%>%
  str_replace("21", "Pest.to.sub")%>%
  str_replace("31", "Guard.to.sub")%>%
  str_replace("32", "Guard.to.pest")

ggstateinv$Parameter<-str_replace_all(ggstateinv$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Guard.to.guard")%>%
  str_replace("21", "Pest.to.guard")%>%
  str_replace("31", "Sub.to.guard")


ggstateinv2<-ggstateinv%>%
  filter(str_detect(Parameter, 'guard'))
#joining fixed so sub/pest/guard combined!



ggstatejustgcwarint<-rbind(ggstate,ggstateinv2)%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('deviance', Parameter))

unique(ggstate$Parameter)

unique(ggstateinv2$Parameter)


ggstatejustgcwarint$Parameter<-str_replace_all(ggstatejustgcwarint$Parameter,"\\[|\\]", "")%>%
  str_replace("betaSub", "Age.rankSub")%>%
  str_replace("betaGuard", "Age.rankGuard")%>%
  str_replace("betaPest", "Age.rankPest")%>%
  str_replace("Sub.to.sub","[Stay.sub]")%>%
  str_replace("Sub.to.pest","[Sub.to.pest]")%>%
  str_replace("Pest.to.pest","[Stay.pest]")%>%
  str_replace("Pest.to.sub","[Pest.to.sub]")%>%
  str_replace("Guard.to.sub","[Guard.to.sub]")%>%
  str_replace("Guard.to.pest","[Guard.to.pest]")%>%
  str_replace("Guard.to.guard","[Stay.guard]")%>%
  str_replace("Pest.to.guard","[Pest.to.guard]")%>%
  str_replace("Sub.to.guard","[Sub.to.guard]")%>%
  str_replace("betacw","GroupCenteredWeight(g)")


ggstatejustgcwaint$Parameter<-str_replace_all(ggstatejustgcwaint$Parameter,"\\[|\\]", "")%>%
  str_replace("betaSub", "AgeSub")%>%
  str_replace("betaGuard", "AgeGuard")%>%
  str_replace("betaPest", "AgePest")%>%
  str_replace("Sub.to.sub","[Stay.sub]")%>%
  str_replace("Sub.to.pest","[Sub.to.pest]")%>%
  str_replace("Pest.to.pest","[Stay.pest]")%>%
  str_replace("Pest.to.sub","[Pest.to.sub]")%>%
  str_replace("Guard.to.sub","[Guard.to.sub]")%>%
  str_replace("Guard.to.pest","[Guard.to.pest]")%>%
  str_replace("Guard.to.guard","[Stay.guard]")%>%
  str_replace("Pest.to.guard","[Pest.to.guard]")%>%
  str_replace("Sub.to.guard","[Sub.to.guard]")%>%
  str_replace("betaq","Age^2(days)")%>%
  str_replace("betacw","GroupCenteredWeight(g)")



ggstatejustgcwaint
ggstatejustgcwarint


ordergcwar <- c(   "Age.rank[Stay.sub]"          ,"Age.rank[Sub.to.guard]"   ,
                   "Age.rank[Guard.to.sub]" ,"Age.rank[Stay.guard]"  ,
                   "GroupCenteredWeight(g)[Stay.sub]"            , "GroupCenteredWeight(g)[Sub.to.guard]" ,
                   "GroupCenteredWeight(g)[Guard.to.sub]"        ,"GroupCenteredWeight(g)[Stay.guard]"      )


ordercwage <- c( "Age(days)[Stay.sub]"          ,"Age^2(days)[Stay.sub]"  ,"Age(days)[Sub.to.guard]"   ,"Age^2(days)[Sub.to.guard]" ,
                 "Age(days)[Guard.to.sub]" , "Age^2(days)[Guard.to.sub]"   ,"Age(days)[Stay.guard]"  , "Age^2(days)[Stay.guard]"  ,  "GroupCenteredWeight(g)[Stay.sub]"       , "GroupCenteredWeight(g)[Sub.to.guard]" ,
                 "GroupCenteredWeight(g)[Guard.to.sub]"   ,"GroupCenteredWeight(g)[Stay.guard]")


ggstatejustgcwarint <-ggstatejustgcwarint %>%filter(!grepl('est', Parameter))#Removing outputs relating to pesterers transitions
ggstatejustgcwaint  <-ggstatejustgcwaint   %>%filter(!grepl('est', Parameter))

ggstatejustall<-rbind(ggstatejustgcwarint,ggstatejustgcwaint%>%filter(!grepl('Weight', Parameter)))

test<-ggstatejustgcwaint%>%filter(!grepl('Weight', Parameter))

catsubguardstateall<-ggs_caterpillar(ggstatejustall%>%na.omit(), line=0, sort=FALSE)+ theme_classic()+ xlim(-1.75,1.75)+
  labs(x="Posterior transition probability (HPD)", y="Parameter")+
  scale_y_discrete(limits=rev)

ggs_density(ggstatejustall, hpd=TRUE)+xlim(-1.75,1.75)+ geom_vline(xintercept = 0)+theme_classic()+labs(y="Posteior samples")

ggs_compare_partial(ggstatejustall)#compares whole chain with the last value
ggs_autocorrelation(ggstatejustall)
ggs_traceplot(ggstatejustall)#traceplot of convergence

ggs_crosscorrelation(ggstatejustall%>%filter(grepl('Stay.guard', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstatejustall%>%filter(grepl('Stay.sub', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstatejustall%>%filter(grepl('Guard.to.sub', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstatejustall%>%filter(grepl('Sub.to.guard', Parameter)))#check for highly correlated dependent variables (deep blue or red)
