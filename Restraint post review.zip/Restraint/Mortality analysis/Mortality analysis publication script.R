#Key
#beta0=age or age rank
#betacw = group centered weight
#betadiff = time difference in days since last oestrus event
#epsg = group
#eps0 = oestrus code.
#epsm = male .id


#Main output objects

#Model objects
#Age rank and weight
OG.fixedargcw.diff.imort.trunc2.noint
#Age and weight
OG.fixedagegcw.diff.imort.trunc2.noint

#Significance tables fixed effects
#Age and weight
table.OG.fixedagegcw.diff.imort.trunc2.noint.lin.olap12.csv
#Age rank and weight
table.OG.fixedargcw12.diff.imort.trunc2.noint.olap.csv

#Significance tables random effect variance
#Age and weight
variancerand2
#Age rank and weight
variancerand

library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)
#Processing data




#Processing time difference data
diffa<-read.csv("matrixoestus.daysnextevent.csv")
diffa<-sapply( diffa, as.numeric )
diffa<-t(as.matrix(diffa))

#Constructing a matrix removing cases where time difference between oestrus events is more than a year. The dimensions are applied to each data matrix
indexkeep<-as.vector(which(diffa[,59] < 365))
diff0<-diffa[indexkeep,]

#Standardising time difference
meandiff<-mean(diff0, na.rm=TRUE)
sddiff<-sd(diff0, na.rm=TRUE)
range(diff0)
quantile(diff0)
?quantile
recoverdiff <- function(x){(sddiff*(x))+meandiff}
standdiff<-function(x){(x-meandiff)/sddiff}
diff<-standdiff(diff0)

#Processing group id data
group <-read_csv("matrixgroupnum.csv")
groupa <- t(as.matrix(group))
group<-groupa[indexkeep,]

#Processing oestrus code data
code<-read_csv("matrixoestrus.codenum.csv")
codea <-t(as.matrix(code))
code<-codea[indexkeep,]
str(code1)
codeb<-as.vector(code)
library(data.table)
codec<-frank(codeb, ties.method = "dense")
code<-matrix(codec, nrow=280, ncol=59)

#Processing group centered weight data
gcweightarchive<-as.matrix(read_csv("weightcenteredrankmatrix.csv"))
gcweightt<-as.matrix(read_csv("weightcenteredrankmatrix.csv"))
write_csv(weightcenteredrankmatrix.csv, "")
gcweighta<-t(gcweightt)

gcweight<-gcweighta[indexkeep,]

mean.gcw <-mean(as.numeric(as.matrix(gcweight)), na.rm =TRUE)
std.gcw<-sd(as.numeric(as.matrix(gcweight)), na.rm =TRUE)
recovergcw <- function(x){(std.gcw*(x))+mean.gcw}
standgcw<-function(x){(x-mean.gcw)/std.gcw}

meangcw2 <-mean(gcweight)
sdgcw2 <-sd(gcweight)
gcweight <- standgcw(gcweight)

#vector for male ID
ind.vec<-seq(1,280,1)


#Male reproductive behaviour state matrix
pCH <- read_csv("matrixstatepest.csv")
pCH <- t(as.matrix(pCH))
pCHa<-pCH
pCH<-pCHa[indexkeep,]
pCH[is.na(pCH)] <- 4


Odataid.agegcw.pmort<-list(n.group = length(levels(as.factor(group))),diff=diff, group =group,ocode = code, age = tableage,  y = pCH, cw = gcweight,
                           n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])


Odataid.arwr.pmort<-list(n.group = length(levels(as.factor(group))),diff=diff, group =group,ocode = code, age = rankage0, y = pCH, cw = gcweight,  
                         n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])


initsall.mort<- function(){list(#alpha0=runif(3, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha0=runif(3, 1e-9, 1e-7),#needs to be the amount of parameters you want
  beta0=runif(3, 1e-9, 1e-7),
  betaq0=runif(3, 1e-9, 1e-7),
  betamf0=runif(3, 1e-9, 1e-7),
  betadiff0=runif(3, 1e-9, 1e-7))}

Oparameters.allmort <- c("alpha0", "beta0", "betacw0", "betadiff0", "epsG0", "epsO0", "epsM0")


ni <-50000 #iterations
nt <- 100 #thining interval
nb <-5000 #burn in
nc <- 3 #chains


#Specifying the model is JAGS syntax

sink("iOG.fixedarwr.diff.noint.mort")#b for base before looking at development# 3 means inta.diffcw
cat("
    model {
    
 
    # M probbability of death
    # Specifying the likelihood function with linear equation

    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:3){
    logit(M[i,j,k])<- alpha0[k]+
    beta0[k]*age[i,j]+
    betacw0[k]*cw[i,j]+
    betadiff0[k]*diff[i,j]+
    epsG0[group[i,j]]+
    epsM0[male[i]]+
    epsO0[ocode[i,j]]

    }}}
    
    #Specyfying priors for mortality probabilities given the reproductive state.
    tau.group0 <- 1 / (sd.group0*sd.group0)#intercepts
    sd.group0 ~ dunif(0, 3)

    tau.ocode0 <- 1 / (sd.ocode0*sd.ocode0)#intercepts
    sd.ocode0 ~ dunif(0, 3)

    
    tau.male0 <- 1 / (sd.male0*sd.male0)#intercepts
    sd.male0 ~ dunif(0, 3)

    for(i in 1:3){
    alpha0[i]~dnorm(0,0.001)
    beta0[i]~dnorm(0,0.001)#age

    betacw0[i]~dnorm(0,0.001)#capture weight

    betadiff0[i]~dnorm(0,0.001)

    }
    for(i in 1:n.group){
    epsG0[i]~ dnorm(0,tau.group0)}
    for(i in 1:n.code){
    epsO0[i]~ dnorm(0,tau.ocode0)}
    for(i in 1:n.male){
    epsM0[i]~ dnorm(0,tau.male0)
    }

    
    for(i in 1:2){
    alpha1[i]~dnorm(0,0.001)
    alpha2[i]~dnorm(0,0.001)
    alpha3[i]~dnorm(0,0.001)
    }
  

    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:2){    
    psia[i,j,k]<-alpha1[k]#+

    psib[i,j,k]<-alpha2[k]#+

    psic[i,j,k]<-alpha3[k]#+

    psiA[i,j,k] <- exp(psia[i,j,k])/(1+exp(psia[i,j,1])+exp(psia[i,j,2]))
    psiB[i,j,k] <- exp(psib[i,j,k])/(1+exp(psib[i,j,1])+exp(psib[i,j,2]))
    psiC[i,j,k] <- exp(psic[i,j,k])/(1+exp(psic[i,j,1])+exp(psic[i,j,2]))}
    psiA[i,j,3] <- 1-psiA[i,j,1]-psiA[i,j,2]
    psiB[i,j,3] <- 1-psiB[i,j,1]-psiB[i,j,2]
    psiC[i,j,3] <- 1-psiC[i,j,1]-psiC[i,j,2]}}

    

    # Define state-transition

    for (i in 1:nind){
    # Define probabilities of state S(t+1) given S(t)
    for (t in 1:(n.occasions-1)){
    ps[1,i,t,1] <- psiA[i,t,1]
    ps[1,i,t,2] <- psiA[i,t,2]
    ps[1,i,t,3] <- psiA[i,t,3]
    ps[1,i,t,4] <- M[i,t,1]
    ps[2,i,t,1] <- psiB[i,t,1]
    ps[2,i,t,2] <- psiB[i,t,2]
    ps[2,i,t,3] <- psiB[i,t,3]
    ps[2,i,t,4] <- M[i,t,2]
    ps[3,i,t,1] <- psiC[i,t,1]
    ps[3,i,t,2] <- psiC[i,t,2]
    ps[3,i,t,3] <- psiC[i,t,3]
    ps[3,i,t,4] <- M[i,t,3]
    ps[4,i,t,1] <- 0
    ps[4,i,t,2] <- 0
    ps[4,i,t,3] <- 0
    ps[4,i,t,4] <- 1
    } #t
    } #i
    
    # Likelihood 
    for (i in 1:nind){
    for (t in 2:n.occasions){
    # State process: draw S(t) given S(t-1)
    y[i,t] ~ dcat(ps[y[i,t-1], i, t-1,]) # This is a profile
    } #t
} #i
    }")
sink()





sink("iOG.fixedagewr.diff.noint.mort")#b for base before looking at development# 3 means inta.diffcw
cat("
    model {
    

    # M probbability of death

    # Specifying the likelihood function with linear equation
    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:3){
    logit(M[i,j,k])<- alpha0[k]+
    beta0[k]*age[i,j]+
    betacw0[k]*cw[i,j]+
    betadiff0[k]*diff[i,j]+
    epsG0[group[i,j]]+
    epsM0[male[i]]+
    epsO0[ocode[i,j]]
    
    
    }}} 

    #Specyfying priors for mortality probabilities given the reproductive state.
    tau.group0 <- 1 / (sd.group0*sd.group0)#intercepts
    sd.group0 ~ dunif(0, 3)
    tau.ocode0 <- 1 / (sd.ocode0*sd.ocode0)#intercepts
    sd.ocode0 ~ dunif(0, 3)
    tau.male0 <- 1 / (sd.male0*sd.male0)#intercepts
    sd.male0 ~ dunif(0, 3)
    
    for(i in 1:3){
    alpha0[i]~dnorm(0,0.001)
    beta0[i]~dnorm(0,0.001)#age
    betacw0[i]~dnorm(0,0.001)#capture weight
    betadiff0[i]~dnorm(0,0.001)
    }
    for(i in 1:n.group){
    epsG0[i]~ dnorm(0,tau.group0)}
    for(i in 1:n.code){
    epsO0[i]~ dnorm(0,tau.ocode0)}
    for(i in 1:n.male){
    epsM0[i]~ dnorm(0,tau.male0)
    }

    for(i in 1:2){
    alpha1[i]~dnorm(0,0.001)
    alpha2[i]~dnorm(0,0.001)
    alpha3[i]~dnorm(0,0.001)
   
    }
    

    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:2){    
    psia[i,j,k]<-alpha1[k]#+
  
    #add priors for behavioural state transitions
    psib[i,j,k]<-alpha2[k]#+
    psic[i,j,k]<-alpha3[k]#+
    psiA[i,j,k] <- exp(psia[i,j,k])/(1+exp(psia[i,j,1])+exp(psia[i,j,2]))
    psiB[i,j,k] <- exp(psib[i,j,k])/(1+exp(psib[i,j,1])+exp(psib[i,j,2]))
    psiC[i,j,k] <- exp(psic[i,j,k])/(1+exp(psic[i,j,1])+exp(psic[i,j,2]))}
    psiA[i,j,3] <- 1-psiA[i,j,1]-psiA[i,j,2]
    psiB[i,j,3] <- 1-psiB[i,j,1]-psiB[i,j,2]
    psiC[i,j,3] <- 1-psiC[i,j,1]-psiC[i,j,2]}}


    # Define state-transition

    for (i in 1:nind){
    # Define probabilities of state S(t+1) given S(t)
    for (t in 1:(n.occasions-1)){
    ps[1,i,t,1] <- psiA[i,t,1]
    ps[1,i,t,2] <- psiA[i,t,2]
    ps[1,i,t,3] <- psiA[i,t,3]
    ps[1,i,t,4] <- M[i,t,1]
    ps[2,i,t,1] <- psiB[i,t,1]
    ps[2,i,t,2] <- psiB[i,t,2]
    ps[2,i,t,3] <- psiB[i,t,3]
    ps[2,i,t,4] <- M[i,t,2]
    ps[3,i,t,1] <- psiC[i,t,1]
    ps[3,i,t,2] <- psiC[i,t,2]
    ps[3,i,t,3] <- psiC[i,t,3]
    ps[3,i,t,4] <- M[i,t,3]
    ps[4,i,t,1] <- 0
    ps[4,i,t,2] <- 0
    ps[4,i,t,3] <- 0
    ps[4,i,t,4] <- 1
    } #t
    } #i
    
    # Likelihood 
    for (i in 1:nind){
    for (t in 2:n.occasions){
    # State process: draw S(t) given S(t-1)
    y[i,t] ~ dcat(ps[y[i,t-1], i, t-1,]) # This is a profile
    } #t
} #i
    }")
sink()


OG.fixedargcw.diff.imort.trunc2.noint<- jagsUI ::jags(Odataid.arwr.pmort, initsall.mort, Oparameters.allmort, "iOG.fixedarwr.diff.noint.mort", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)


OG.fixedagegcw.diff.imort.trunc2.noint<- jagsUI ::jags(Odataid.agegcw.pmort, initsall.mort, Oparameters.allmort, "iOG.fixedagewr.diff.noint.mort", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)


#Extracting output table


OG.fixedargcw.diff.imort.trunc2.nointsum<-MCMCsummary(OG.fixedargcw.diff.imort.trunc2.noint, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OG.fixedargcw.diff.imort.trunc2.nointsum)
OG.fixedargcw.diff.imort.trunc2.noint.olap<-OG.fixedargcw.diff.imort.trunc2.nointsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                                 low < 0 & high< 0~"-",
                                                                                                                 TRUE ~"NotSignif"))

write.csv(OG.fixedargcw.diff.imort.trunc2.noint.olap, "OG.fixedargcw.diff.imort.trunc2.noint.olap.csv")#to make ghost name column a real column
FOG.fixedargcw.diff.imort.trunc2.noint.olap<-read.csv("OG.fixedargcw.diff.imort.trunc2.noint.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OG.fixedargcw.diff.imort.trunc2.noint$f)),as.data.frame(matrix(unlist(OG.fixedargcw.diff.imort.trunc2.noint$f ))))%>%rename("X"="names(unlist(OG.fixedargcw.diff.imort.trunc2.noint$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))%>%filter(!grepl('betaq', X))#mcmc doesn't give f output so need to rejoin it


table.OG.fixedagegcw.diff.imort.trunc2.noint.lin.olap12.csv<-FOG.fixedargcw.diff.imort.trunc2.noint.olap%>%filter(!grepl("2",X))


OG.fixedargcw.diff.imort.trunc2.nointsum<-MCMCsummary(OG.fixedargcw.diff.imort.trunc2.noint, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OG.fixedargcw.diff.imort.trunc2.nointsum)
OG.fixedargcw.diff.imort.trunc2.noint.olap<-OG.fixedargcw.diff.imort.trunc2.nointsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                                 low < 0 & high< 0~"-",
                                                                                                                 TRUE ~"NotSignif"))

write.csv(OG.fixedargcw.diff.imort.trunc2.noint.olap, "OG.fixedargcw.diff.imort.trunc2.noint.olap.csv")#to make ghost name column a real column
FOG.fixedargcw.diff.imort.trunc2.noint.olap<-read.csv("OG.fixedargcw.diff.imort.trunc2.noint.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OG.fixedargcw.diff.imort.trunc2.noint$f)),as.data.frame(matrix(unlist(OG.fixedargcw.diff.imort.trunc2.noint$f ))))%>%rename("X"="names(unlist(OG.fixedargcw.diff.imort.trunc2.noint$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))%>%filter(!grepl('betaq', X))#mcmc doesn't give f output so need to rejoin it
table.OG.fixedargcw12.diff.imort.trunc2.noint.olap.csv<-FOG.fixedargcw.diff.imort.trunc2.noint.olap%>%filter(!grepl("2",X))




variancerand<-ggs(OG.fixedargcw.diff.imort.trunc2.noint$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()
variancerand2<-ggs(OG.fixedagegcw.diff.imort.trunc2.noint$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()















#Using ggmcmc to make significance plots and diagnostic graphs.

ggOG.fixedagegcw.diff.imort.trunc2.noint.lin<-ggs(OG.fixedagegcw.diff.imort.trunc2.noint.lin$samples)%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('2', Parameter))%>%mutate(From=case_when(grepl('1', Parameter) ~ "Subordinate",
                                                                                                                    grepl('3', Parameter) ~ "Guard"))%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%mutate(Parameter=case_when(
    Parameter=="alpha0[1]" ~    "alpha[Subordinate]",
    Parameter=="alpha0[3]"   ~"alpha[Guard]",
    Parameter=="beta0[1]"   ~"Age[Subordinate]",
    Parameter=="beta0[3]"   ~"Age[Guard]",
    Parameter=="betadiff0[1]"~"TimeDifference[Subordinate]",
    Parameter=="betadiff0[3]"~"TimeDifference[Guard]",
    Parameter=="betacw0[1]"   ~"GroupCenteredWeight[Subordinate]",
    Parameter=="betacw0[3]"   ~"GroupCenteredWeight[Guard]"
  ))%>%arrange(desc(Parameter))%>%drop_na(Parameter)





ggOG.fixedargcw.imort.trunc2.noint<-ggs(OG.fixedargcw.imort.trunc2.noint$samples)%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('2', Parameter))%>%mutate(From=case_when(grepl('1', Parameter) ~ "Subordinate",
                                                                                                          grepl('3', Parameter) ~ "Guard"))%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%mutate(Parameter=case_when(
    Parameter=="alpha0[1]" ~    "alpha[Subordinate]",
    Parameter=="alpha0[3]"   ~"alpha[Guard]",
    Parameter=="beta0[1]"   ~"AgeRank[Subordinate]",
    Parameter=="beta0[3]"   ~"AgeRank[Guard]",
    Parameter=="betadiff0[1]"~"TimeDifference[Subordinate]",
    Parameter=="betadiff0[3]"~"TimeDifference[Guard]",
    Parameter=="betacw0[1]"   ~"GroupCenteredWeight[Subordinate]",
    Parameter=="betacw0[3]"   ~"GroupCenteredWeight[Guard]"
  ))%>%arrange(desc(Parameter))%>%drop_na(Parameter)

#significance and diagnostic plots
ggs_caterpillar(ggOG.fixedagegcw.diff.imort.trunc2.noint.lin)+xlim(-2,2)+ geom_vline(xintercept = 0)+theme_classic()
ggs_caterpillar(ggOG.fixedargcw.imort.trunc2.noint)+xlim(-2,2)+ geom_vline(xintercept = 0)+theme_classic()
ggs_density(ggOG.fixedagegcw.diff.imort.trunc2.noint.lin, hpd=TRUE)+xlim(-2,2)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")
ggs_density(ggOG.fixedargcw.imort.trunc2.noint, hpd=TRUE)+xlim(-2,2)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggOG.fixedagegcw.diff.imort.trunc2.noint.lin)#compares whole chain with the last value
ggs_compare_partial(ggOG.fixedargcw.imort.trunc2.noint)#compares whole chain with the last value
ggs_autocorrelation(ggOG.fixedagegcw.diff.imort.trunc2.noint.lin)
ggs_autocorrelation(ggOG.fixedargcw.imort.trunc2.noint)
ggs_traceplot(ggOG.fixedagegcw.diff.imort.trunc2.noint.lin)#traceplot of convergence
ggs_traceplot(ggOG.fixedargcw.imort.trunc2.noint)#traceplot of convergence
ggs_crosscorrelation(ggOG.fixedagegcw.diff.imort.trunc2.noint.lin)#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggOG.fixedargcw.imort.trunc2.noint)#check for highly correlated dependent variables (deep blue or red)
