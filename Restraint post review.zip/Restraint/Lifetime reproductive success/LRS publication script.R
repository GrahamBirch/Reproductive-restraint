#Key
#beta= Male age (rank or days)
#betaw = Male weight (group centered or absolute in grams)
#intaaw = interaction between age rank and group centered weight
#alpha = intercept
#alphapsi = zero inflated intercept
#epsG = random effect for group


#Model object
LRS1.rawfixed#absolute age and weight
LRS1.socfixed#age rank and group centered weight
#Model objects for non-significant interactions
LRS1.rawfixed
LRS1.socfixed

#Significance tables fixed effects
table.LRS1.socfixed
table.LRS1.rawfixed
#Significance tables random effect variance
variancerandcwageLRS
variancerandgcwarLRS


firstguardcharacteristicspub<-read.csv("firstguarddata.csv")

count(firstguardcharacteristicspub$LRS)

firstguardcharacteristicspub%>%select(LRS, id)%>%distinct()%>%group_by(LRS)%>%mutate(n=n())%>%ungroup()%>%select(LRS, n)%>%distinct()

LRSinits<- function(){list(#alpha0=runif(3, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha=runif(1, 1e-9, 1e-7),
  beta=runif(1, 1e-9, 1e-7),
  betaw=runif(1, 1e-9, 1e-7)
  
)}

LRSparameters <- c(
  "alpha", "beta", "betaw","intaaw", "alphapsi", "epsG")


jags.LRSdata <- list( y = firstguardcharacteristicspub$LRS,n = length(firstguardcharacteristicspub$LRS),
                      group = firstguardcharacteristicspub$groupn,
                      groupl= length(levels(as.factor(round(firstguardcharacteristicspub$groupn)))),
                      a=standage(firstguardcharacteristicspub$Age),
                      cw=standcw(firstguardcharacteristicspub$Weight))

jags.LRSdata.social <- list( y = firstguardcharacteristicspub$LRS,n = length(firstguardcharacteristicspub$LRS),
                             group = firstguardcharacteristicspub$groupn,
                             groupl= length(levels(as.factor(round(firstguardcharacteristicspub$groupn)))),
                             a=firstguardcharacteristicspub$ar,
                             cw=firstguardcharacteristicspub$gcw)


#JAGS specified models
sink("zifitnessint")
cat("model{
  ## Likelihood
  for(i in 1:n){
    y[i] ~ dnegbin(p[i],r)
    p[i] <-  r/(r+mu[i])#negative binomial componant
    log(mu[i])<-z[i]*lambda.count[i] +0.00000000000001
    lambda.count[i] <- alpha+beta*a[i]+betaw*cw[i]+intaaw*a[i]*cw[i]+epsG[group[i]]
    
    ## Zero-Inflation
    z[i] ~ dbern(psi[i])
    logit(psi[i]) <- alphapsi
  } 
  
    for(i in 1:groupl){
  epsG[i]~ dnorm(0,tau.g)}
    tau.g <- 1 / (sd.g*sd.g)
  sd.g ~ dunif(0, 1)
  
  ## Priors
  alpha ~ dnorm(0, .001)
  alphapsi~ dnorm(0, .001)
  beta~ dnorm(0, .001)
  betaw~ dnorm(0, .001)
  intaaw~ dnorm(0, .001)
  r ~ dgamma(0.001,0.001)
}
")
sink()





sink("zifitnessfixed")
cat("model{
  ## Likelihood
  for(i in 1:n){
    y[i] ~ dnegbin(p[i],r)
    p[i] <-  r/(r+mu[i])#negative binomial componant
    log(mu[i])<-z[i]*lambda.count[i] +0.00000000000001
    lambda.count[i] <- alpha+beta*a[i]+betaw*cw[i]+epsG[group[i]]
    
    ## Zero-Inflation
    z[i] ~ dbern(psi[i])
    logit(psi[i]) <- alphapsi
  } 
  
    for(i in 1:groupl){
  epsG[i]~ dnorm(0,tau.g)}
    tau.g <- 1 / (sd.g*sd.g)
  sd.g ~ dunif(0, 1)
  
  ## Priors
  alpha ~ dnorm(0, .001)
  alphapsi~ dnorm(0, .001)
  beta~ dnorm(0, .001)
  betaw~ dnorm(0, .001)
  r ~ dgamma(0.001,0.001)
}
")
sink()




LRS1.rawint<- jagsUI ::jags(jags.LRSdata, LRSinits, LRSparameters, "zifitnessint", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)

LRS1.rawfixed<- jagsUI ::jags(jags.LRSdata, LRSinits, LRSparameters, "zifitnessfixed", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)


LRS1.socint<- jagsUI ::jags(jags.LRSdata.social, LRSinits, LRSparameters, "zifitnessint", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)

LRS1.socfixed<- jagsUI ::jags(jags.LRSdata.social, LRSinits, LRSparameters, "zifitnessfixed", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)



#Extracting data from posteriors for model diagnostic plots 

ggLRS1.socfixed2<-ggs(LRS1.socfixed2$samples)
ggLRS1.socfixed2<-ggLRS1.socfixed2%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('alphapsi', Parameter))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('eps', Parameter))%>%arrange(Parameter)#making seperate random dataframe and filtering fixed
ggs_traceplot(ggLRS1.socfixed2%>%filter(grepl('beta', Parameter)))
ggLRS1.socfixed2<-ggs(LRS1.socfixed2$samples)%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%filter(!grepl('eps', Parameter))%>%mutate(Parameter=case_when(
    Parameter=="beta" ~    "AgeRank",
    Parameter=="betaw"  ~"GroupCenteredWeight(g)",
    Parameter=="beta2"  ~"AgeRank2"
  ))%>%arrange(desc(Parameter))%>%na.omit()


unique(ggLRS1.socfixed2$Parameter2)
#significance plots
ggs_caterpillar(ggLRS1.socfixed2)+xlim(-0.5,1)+ geom_vline(xintercept = 0)+theme_classic()
ggs_density(ggLRS1.socfixed2, hpd=TRUE)+xlim(-0.5,1)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggLRS1.socfixed2)#compares whole chain with the last value
ggs_autocorrelation(ggLRS1.socfixed2)
ggs_traceplot(ggLRS1.socfixed2)#traceplot of convergence
ggs_crosscorrelation(ggLRS1.socfixed2)#check for highly correlated dependent variables (deep blue or red)




ggLRS1.socfixed<-ggs(LRS1.socfixed$samples)
ggLRS1.socfixed<-ggLRS1.socfixed%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('alphapsi', Parameter))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('eps', Parameter))%>%arrange(Parameter)#making seperate random dataframe and filtering fixed
ggs_traceplot(ggLRS1.socfixed%>%filter(grepl('beta', Parameter)))
ggLRS1.socfixed<-ggs(LRS1.socfixed$samples)%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%filter(!grepl('eps', Parameter))%>%mutate(Parameter=case_when(
    Parameter=="beta" ~    "AgeRank",
    Parameter=="betaw"  ~"GroupCenteredWeight(g)",
    Parameter=="intaaw"  ~"AR:GCW"
  ))%>%arrange(desc(Parameter))%>%na.omit()


ggs_caterpillar(ggLRS1.socfixed)+xlim(-1,1.5)+ geom_vline(xintercept = 0)+theme_classic()
ggs_density(ggLRS1.socfixed, hpd=TRUE)+xlim(-1,1.5)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggLRS1.socfixed)#compares whole chain with the last value
ggs_autocorrelation(ggLRS1.socfixed)
ggs_traceplot(ggLRS1.socfixed)#traceplot of convergence
ggs_crosscorrelation(ggLRS1.socfixed)#check for highly correlated dependent variables (deep blue or red)


ggLRS1.socint<-ggs(LRS1.socint$samples)
ggLRS1.socint<-ggLRS1.socint%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('alphapsi', Parameter))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('eps', Parameter))%>%arrange(Parameter)#making seperate random dataframe and filtering fixed
ggs_traceplot(ggLRS1.socint%>%filter(grepl('beta', Parameter)))
ggLRS1.socint<-ggs(LRS1.socint$samples)%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%filter(!grepl('eps', Parameter))%>%mutate(Parameter=case_when(
    Parameter=="beta" ~    "AgeRank",
    Parameter=="betaw"  ~"GroupCenteredWeight(g)",
    Parameter=="intaaw"  ~"AR:GCW"
  ))%>%arrange(desc(Parameter))%>%na.omit()


unique(ggLRS1.socint$Parameter2)
#significance plots
ggs_caterpillar(ggLRS1.socint)+xlim(-1,1.5)+ geom_vline(xintercept = 0)+theme_classic()
ggs_density(ggLRS1.socint, hpd=TRUE)+xlim(-1,1.5)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggLRS1.socint)#compares whole chain with the last value
ggs_autocorrelation(ggLRS1.socint)
ggs_traceplot(ggLRS1.socint)#traceplot of convergence
ggs_crosscorrelation(ggLRS1.socint)#check for highly correlated dependent variables (deep blue or red)





#Extracting significance tables from model object
LRS1.socintsum<-MCMCsummary(LRS1.socint, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(ms1sum)
LRS1.socintsum.olap<-LRS1.socintsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                low < 0 & high< 0~"-",
                                                                TRUE ~"NotSignif"))


write.csv(LRS1.socintsum.olap, "OLRS1.socintsum.olap.csv")#to make ghost name column a real column
OLRS1.socintsum.olap<-read.csv("OLRS1.socintsum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(LRS1.socint$f)),as.data.frame(matrix(unlist(LRS1.socint$f ))))%>%rename("X"="names(unlist(LRS1.socint$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it

write.csv(OLRS1.socintsum.olap, "table.OLRS1.socintsum.olap.csv")

table.LRS1.socint<-read.csv("table.OLRS1.socintsum.olap.csv")


getwd()


LRS1.socfixedsum<-MCMCsummary(LRS1.socfixed, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(ms1sum)
LRS1.socfixedsum.olap<-LRS1.socfixedsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                    low < 0 & high< 0~"-",
                                                                    TRUE ~"NotSignif"))


write.csv(LRS1.socfixedsum.olap, "OLRS1.socfixedsum.olap.csv")#to make ghost name column a real column
OLRS1.socfixedsum.olap<-read.csv("OLRS1.socfixedsum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(LRS1.socfixed$f)),as.data.frame(matrix(unlist(LRS1.socfixed$f ))))%>%rename("X"="names(unlist(LRS1.socfixed$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it

write.csv(OLRS1.socfixedsum.olap, "table.OLRS1.socfixedsum.olap.csv")

table.LRS1.socfixed<-read.csv("table.OLRS1.socfixedsum.olap.csv")



LRS1.rawfixedsum<-MCMCsummary(LRS1.rawfixed, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(ms1sum)
LRS1.rawfixedsum.olap<-LRS1.rawfixedsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                    low < 0 & high< 0~"-",
                                                                    TRUE ~"NotSignif"))


str(Omsb.id.WR.age.olap)
write.csv(LRS1.rawfixedsum.olap, "OLRS1.rawfixedsum.olap.csv")#to make ghost name column a real column
OLRS1.rawfixedsum.olap<-read.csv("OLRS1.rawfixedsum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(LRS1.rawfixed$f)),as.data.frame(matrix(unlist(LRS1.rawfixed$f ))))%>%rename("X"="names(unlist(LRS1.rawfixed$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it

write.csv(OLRS1.rawfixedsum.olap, "table.OLRS1.rawfixedsum.olap.csv")

table.LRS1.rawfixed<-read.csv("table.OLRS1.rawfixedsum.olap.csv")



variancerandcwageLRS<-ggs(LRS1.rawfixed$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()
variancerandgcwarLRS<-ggs(LRS1.socfixed$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()
variancerandgcwarLRSint<-ggs(LRS1.socint$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()


